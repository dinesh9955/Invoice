package com.sirapp.Model;

/**
 * Created by Fawad on 4/17/2020.
 */

public class Service_list {

    public String getService_id() {
        return service_id;
    }

    public void setService_id(String service_id) {
        this.service_id = service_id;
    }

    public String getCompany_id() {
        return company_id;
    }

    public void setCompany_id(String company_id) {
        this.company_id = company_id;
    }

    public String getService_name() {
        return service_name;
    }

    public void setService_name(String service_name) {
        this.service_name = service_name;
    }

    public String getService_price() {
        return service_price;
    }

    public void setService_price(String service_price) {
        this.service_price = service_price;
    }

    public String getService_description() {
        return service_description;
    }

    public void setService_description(String service_description) {
        this.service_description = service_description;
    }

    public String getService_taxable() {
        return service_taxable;
    }

    public void setService_taxable(String service_taxable) {
        this.service_taxable = service_taxable;
    }

    String service_id;
    String company_id;
    String service_name;
    String service_price;
    String service_description;
    String service_taxable;

    public String getMeasurement_unit() {
        return measurement_unit;
    }

    public void setMeasurement_unit(String measurement_unit) {
        this.measurement_unit = measurement_unit;
    }

    String measurement_unit;

    public String getCuurency_code() {
        return cuurency_code;
    }

    public void setCuurency_code(String cuurency_code) {
        this.cuurency_code = cuurency_code;
    }

    String cuurency_code;

    public String getService_category() {
        return service_category;
    }

    public void setService_category(String service_category) {
        this.service_category = service_category;
    }

    String service_category;

    public String getService_price_unit() {
        return service_price_unit;
    }

    public void setService_price_unit(String service_price_unit) {
        this.service_price_unit = service_price_unit;
    }

    String service_price_unit;

    public String getService_quantity() {
        return service_quantity;
    }

    public void setService_quantity(String service_quantity) {
        this.service_quantity = service_quantity;
    }

    String service_quantity;








}
