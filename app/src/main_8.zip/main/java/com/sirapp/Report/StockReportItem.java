package com.sirapp.Report;

import java.io.Serializable;

public class StockReportItem implements Serializable {

    String date_added = "";
    String product_id = "";
    String name = "";
    String minimum = "";
    String quantity = "";
    String quantity_status = "";
    String price = "";
    String value = "";

    public String getDate_added() {
        return date_added;
    }

    public void setDate_added(String date_added) {
        this.date_added = date_added;
    }

    public String getProduct_id() {
        return product_id;
    }

    public void setProduct_id(String product_id) {
        this.product_id = product_id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getMinimum() {
        return minimum;
    }

    public void setMinimum(String minimum) {
        this.minimum = minimum;
    }

    public String getQuantity() {
        return quantity;
    }

    public void setQuantity(String quantity) {
        this.quantity = quantity;
    }

    public String getQuantity_status() {
        return quantity_status;
    }

    public void setQuantity_status(String quantity_status) {
        this.quantity_status = quantity_status;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }
}
