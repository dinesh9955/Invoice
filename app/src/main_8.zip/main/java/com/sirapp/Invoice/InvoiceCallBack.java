package com.sirapp.Invoice;

import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public interface InvoiceCallBack {
    public abstract void callBack(String status);

}
