package com.sirapp.Model;

public class Moving {

    public String getCus_name() {
        return cus_name;
    }

    public void setCus_name(String cus_name) {
        this.cus_name = cus_name;
    }

    String cus_name;

    public String getSelectedcus_id() {
        return selectedcus_id;
    }

    public void setSelectedcus_id(String selectedcus_id) {
        this.selectedcus_id = selectedcus_id;
    }

    String selectedcus_id;

}
