package com.sirapp.Model;

import java.util.HashMap;
import java.util.Map;

public class InvoiceCalculate{
    public String getAmounttotal() {

        return amounttotal;
    }

    public void setAmounttotal(String amounttotal) {
        this.amounttotal = amounttotal;
    }

    private  String amounttotal;

}
