package com.sirapp.POJO.Invoice;

public class InvoiceImage{
    public String order_image_id;
    public String ref_id;
    public String order_product_type;
    public String image;
    public String sort_order;
}
