package com.sirapp.Tax;

public class Taxlistbycompany {

    public String getTaxnamebycompany() {
        return taxnamebycompany;
    }

    public void setTaxnamebycompany(String taxnamebycompany) {
        this.taxnamebycompany = taxnamebycompany;
    }

    public String getTax_ratebycompany() {
        return tax_ratebycompany;
    }

    public void setTax_ratebycompany(String tax_ratebycompany) {
        this.tax_ratebycompany = tax_ratebycompany;
    }

    String taxnamebycompany;
    String tax_ratebycompany;

}
