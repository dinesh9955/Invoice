package com.sirapp.API;

public class AllSirApi {

//    public static final String BASE_LEVEL_HTTP ="https://sir-app.com/";


    public static final String BASE_LEVEL ="https://sir-app.com/";
    public static final String BASE = BASE_LEVEL+"app/";
    public static final String BASE_URL = BASE+"api/";

//    public static final String BASE_LEVEL ="http://prod.webdevelopmentsolution.net/saad/";
//    public static final String BASE = BASE_LEVEL+"app/";
//    public static final String BASE_URL = BASE+"index.php/api/";

//    public static final String BASE_LEVEL ="http://prod.webdevelopmentsolution.net/saad/";
//    public static final String BASE = BASE_LEVEL+"app/";
//    public static final String BASE_URL = BASE+"index.php/api/";

//    public static final String BASE_URL = BASE+"index.php/api/";

//    public static final String BASE_URL = BASE;

//    https://sir-app.com/app/api/user/login

    public static final boolean FONT_INVOICE = false;
    public static final int FONT_SIZE = 7;

    public static final boolean FONT_INVOICE_CREATE = true;
    public static final int FONT_SIZE_CREATE = 6;

    public static final boolean FONT_INVOICE_CREATE_LDPI = false;
    public static final int FONT_SIZE_CREATE_LDPI = 4;

    public static final boolean FONT_SIZE_PRINT_VIEW = true;
    public static final int FONT_SIZE_PRINT = 6;

    public static final boolean FONT_INVOICE_CREATE_TAB = true;


    public static final int FONT_SIZE_CREATE_TAB_10 = 4;
    public static final int FONT_SIZE_CREATE_TAB_7 = 7;

    public static final int FONT_SIZE_CREATE_L = 3;
    public static final int FONT_SIZE_CREATE_M = 4;
    public static final int FONT_SIZE_CREATE_H = 5;
    public static final int FONT_SIZE_CREATE_X = 6;
    public static final int FONT_SIZE_CREATE_XX = 5;
    public static final int FONT_SIZE_CREATE_XXX = 4;



    public static final int FONT_SIZE_CREATE_TAB_10_V = 6;
    public static final int FONT_SIZE_CREATE_TAB_7_V = 9;

    public static final int FONT_SIZE_CREATE_L_V = 7;
    public static final int FONT_SIZE_CREATE_M_V = 8;
    public static final int FONT_SIZE_CREATE_H_V = 9;
    public static final int FONT_SIZE_CREATE_X_V = 10;
    public static final int FONT_SIZE_CREATE_XX_V = 10;
    public static final int FONT_SIZE_CREATE_XXX_V = 10;


    public static final boolean ALL_FONT = false;


//    public static final String BASE_URL ="http://13.126.22.0/saad/app/index.php/api/";

//    public static final String BASE_URL_PDF = "http://13.126.22.0/saad/app/uploads/invoice/pdf/";

//    public static final String BASE_URL ="https://sir-app.com/app/";
//    http://13.126.22.0/saad/app/index.php/view/invoice/

    public static final String BASE_URL_INDEX = BASE+"index.php/";

    public static final String Home = BASE_URL+"company/home";
    public static final String COMPANYListing = BASE_URL + "company/listing";
    public static final String InvoiceGetListing = BASE_URL + "invoice/getListingByCompany";

    public static final String LICENSE_KEY = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAhjGS/Tdhto9derrxOp0d8wprjdH+kK/oyq3KBy+dnZnsLdUeD2uruNRg6ezOkBEazTWSvtXH2ABNbGhGHvwHqaeyV8A9zqcGVF10XOYCYtj6QWsd4+6ORCVOT+H4/dogj9QC/80BBbjF4QviAh5rYWzR/rTtEmOL2GVaQ+TC5WIFqQ3G7y4V9EjfKqpE1bGEf4N/WY8S11belIjbM82rcVW2MgmkVfHjFy27zHz9n+B2TAOEBQQ08V4QXGALVXmo4ELZuuxcEkLIQducAKnbpdL1S+MV6Hk9yRARe7bQDGnT9mzVcmoTUR9sBo8tOn7Yg4xc9pCwuNK09bsshz913QIDAQAB"; // PUT YOUR MERCHANT KEY HERE;


//    public static String BASE_URL = "http://13.126.22.0/saad/app/index.php/api/";
//    public static String BASE_URL_PDF = "http://13.126.22.0/saad/app/uploads/invoice/pdf/";
//    public static String BASE_URL_SUPPORT = "http://13.126.22.0/saad/wp-content/api/";
//    public static String BASE_URL_PAYMENT = "http://prod.webdevelopmentsolution.net/saad/app/index.php/api/";

    public static String BASE_URL_PDF = BASE+"uploads/invoice/pdf/";
    public static String BASE_URL_SUPPORT = BASE_LEVEL+"wp-content/api/";
    public static String BASE_URL_PAYMENT = "http://prod.webdevelopmentsolution.net/saad/app/index.php/api/";

}


