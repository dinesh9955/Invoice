package com.sirapp.POJO.Invoice;

public class Product{
    public String order_product_id;
    public String product_id;
    public String name;
    public String description;
    public String measurement_unit;
    public String measurement_unit_short;
    public String quantity;
    public String price;
    public String total;
}
