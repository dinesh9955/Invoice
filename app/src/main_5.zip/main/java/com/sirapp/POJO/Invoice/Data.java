package com.sirapp.POJO.Invoice;

import java.util.List;

public class Data{
    public Invoice invoice;
    public List<InvoiceImage> invoice_image;
    public String invoice_image_path;
    public String invoice_pdf_path;
    public String company_image_path;
    public String customer_image_path;
    public String invoice_share_link;
}
