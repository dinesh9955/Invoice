package com.sirapp.Home;

public interface MenuDelegate {
    public void onMenuItemClick(String menuName);
}
