package com.sirapp.API;

public class Parameters {

      public String  FULLNAME = "fullName";
      public static final String  AUTH_KEY = "Access-Token";
      public static final String  COMPANY_ID = "company_id";

}
