package com.sirapp.Model;

/**
 * Created by Fawad on 6/25/2020.
 */

public class User_list {

    public String getUser_id() {
        return user_id;
    }

    public void setUser_id(String user_id) {
        this.user_id = user_id;
    }

    public String getEmail_id() {
        return email_id;
    }

    public void setEmail_id(String email_id) {
        this.email_id = email_id;
    }

    public String getFull_name() {
        return full_name;
    }

    public void setFull_name(String full_name) {
        this.full_name = full_name;
    }

    public String getPhone_number() {
        return phone_number;
    }

    public void setPhone_number(String phone_number) {
        this.phone_number = phone_number;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public String getInvoice() {
        return invoice;
    }

    public void setInvoice(String invoice) {
        this.invoice = invoice;
    }

    public String getEstimate() {
        return estimate;
    }

    public void setEstimate(String estimate) {
        this.estimate = estimate;
    }

    public String getStock() {
        return stock;
    }

    public void setStock(String stock) {
        this.stock = stock;
    }

    public String getReceipt() {
        return receipt;
    }

    public void setReceipt(String receipt) {
        this.receipt = receipt;
    }

    public String getPurchase_order() {
        return purchase_order;
    }

    public void setPurchase_order(String purchase_order) {
        this.purchase_order = purchase_order;
    }

    public String getPayment_voucher() {
        return payment_voucher;
    }

    public void setPayment_voucher(String payment_voucher) {
        this.payment_voucher = payment_voucher;
    }

    public String getTax() {
        return tax;
    }

    public void setTax(String tax) {
        this.tax = tax;
    }

    public String getCustomer() {
        return customer;
    }

    public void setCustomer(String customer) {
        this.customer = customer;
    }

    public String getSupplier() {
        return supplier;
    }

    public void setSupplier(String supplier) {
        this.supplier = supplier;
    }

    public String getProduct() {
        return product;
    }

    public void setProduct(String product) {
        this.product = product;
    }

    public String getService() {
        return service;
    }

    public void setService(String service) {
        this.service = service;
    }

    public String getDebit_note() {
        return debit_note;
    }

    public void setDebit_note(String debit_note) {
        this.debit_note = debit_note;
    }

    public String getCredit_note() {
        return credit_note;
    }

    public void setCredit_note(String credit_note) {
        this.credit_note = credit_note;
    }

    public String getSub_admin() {
        return sub_admin;
    }

    public void setSub_admin(String sub_admin) {
        this.sub_admin = sub_admin;
    }

    public String user_id;
    public String email_id;
    public String full_name;
    public String phone_number;
    public String role;
    public String invoice;
    public String estimate;
    public String stock;
    public String receipt;
    public String purchase_order;
    public String payment_voucher;
    public String tax;
    public String customer;
    public String supplier;
    public String product;
    public String service;
    public String debit_note;
    public String credit_note;
    public String sub_admin;

    public  String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public  String image;

    public  String getImage_path() {
        return image_path;
    }

    public void setImage_path(String image_path) {
        this.image_path = image_path;
    }

    public String image_path;




}
