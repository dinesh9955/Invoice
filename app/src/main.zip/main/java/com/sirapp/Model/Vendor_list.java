package com.sirapp.Model;

/**
 * Created by Fawad on 4/17/2020.
 */

public class Vendor_list {


    public String getVendor_id() {
        return vendor_id;
    }

    public void setVendor_id(String vendor_id) {
        this.vendor_id = vendor_id;
    }

    public String getVendor_name() {
        return vendor_name;
    }

    public void setVendor_name(String vendor_name) {
        this.vendor_name = vendor_name;
    }

    public String getVendor_contact_person() {
        return vendor_contact_person;
    }

    public void setVendor_contact_person(String vendor_contact_person) {
        this.vendor_contact_person = vendor_contact_person;
    }

    public String getVendor_address() {
        return vendor_address;
    }

    public void setVendor_address(String vendor_address) {
        this.vendor_address = vendor_address;
    }

    public String getVendor_image() {
        return vendor_image;
    }

    public void setVendor_image(String vendor_image) {
        this.vendor_image = vendor_image;
    }

    public String getVendor_email() {
        return vendor_email;
    }

    public void setVendor_email(String vendor_email) {
        this.vendor_email = vendor_email;
    }

    public String getVendor_phone() {
        return vendor_phone;
    }

    public void setVendor_phone(String vendor_phone) {
        this.vendor_phone = vendor_phone;
    }

    public String getVendor_mobile() {
        return vendor_mobile;
    }

    public void setVendor_mobile(String vendor_mobile) {
        this.vendor_mobile = vendor_mobile;
    }

    public String getVendor_website() {
        return vendor_website;
    }

    public void setVendor_website(String vendor_website) {
        this.vendor_website = vendor_website;
    }

    public String getVendor_image_path() {
        return vendor_image_path;
    }

    public void setVendor_image_path(String vendor_image_path) {
        this.vendor_image_path = vendor_image_path;
    }

    String vendor_id;
    String vendor_name;
    String vendor_contact_person;
    String vendor_address;
    String vendor_image;
    String vendor_email;
    String vendor_phone;
    String vendor_mobile;
    String vendor_website;
    String vendor_image_path;
}
