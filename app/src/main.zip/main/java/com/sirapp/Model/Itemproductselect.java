package com.sirapp.Model;

public class Itemproductselect {

    String product_id;
    String product_name;
    String product_price;
    String product_totleprice;
    String product_price_unit;
    String productquentity;

    public String getProduct_id() {
        return product_id;
    }

    public void setProduct_id(String product_id) {
        this.product_id = product_id;
    }

    public String getProduct_name() {
        return product_name;
    }

    public void setProduct_name(String product_name) {
        this.product_name = product_name;
    }

    public String getProduct_price() {
        return product_price;
    }

    public void setProduct_price(String product_price) {
        this.product_price = product_price;
    }

    public String getProduct_totleprice() {
        return product_totleprice;
    }

    public void setProduct_totleprice(String product_totleprice) {
        this.product_totleprice = product_totleprice;
    }

    public String getProduct_price_unit() {
        return product_price_unit;
    }

    public void setProduct_price_unit(String product_price_unit) {
        this.product_price_unit = product_price_unit;
    }

    public String getProductquentity() {
        return productquentity;
    }

    public void setProductquentity(String productquentity) {
        this.productquentity = productquentity;
    }




}
