package com.sirapp.Model;

public class AttchmentImage {
    public String getImgpath() {
        return imgpath;
    }

    public void setImgpath(String imgpath) {
        this.imgpath = imgpath;
    }

    private  String imgpath;
}
