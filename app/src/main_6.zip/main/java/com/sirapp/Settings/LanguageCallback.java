package com.sirapp.Settings;

public interface LanguageCallback {
    public void onLanguageClickBack(int position);
}
