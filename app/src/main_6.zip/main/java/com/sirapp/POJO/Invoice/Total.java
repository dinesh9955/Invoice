package com.sirapp.POJO.Invoice;

public class Total{
    public String code;
    public String title;
    public String value;
}
