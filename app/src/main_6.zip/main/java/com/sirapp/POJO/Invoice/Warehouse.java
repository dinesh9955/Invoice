package com.sirapp.POJO.Invoice;

public class Warehouse{
    public String warehouse_id;
    public String company_id;
    public String name;
    public Object description;
    public String address;
    public String date_added;
}
