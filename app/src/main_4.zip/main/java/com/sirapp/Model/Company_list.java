package com.sirapp.Model;

/**
 * Created by Fawad on 4/17/2020.
 */

public class Company_list {

    public String getCompany_id() {
        return company_id;
    }

    public void setCompany_id(String company_id) {
        this.company_id = company_id;
    }

    public String getCompany_name() {
        return company_name;
    }

    public void setCompany_name(String company_name) {
        this.company_name = company_name;
    }

    public String getCompany_phone() {
        return company_phone;
    }

    public void setCompany_phone(String company_phone) {
        this.company_phone = company_phone;
    }

    public String getCompany_email() {
        return company_email;
    }

    public void setCompany_email(String company_email) {
        this.company_email = company_email;
    }

    public String getCompany_website() {
        return company_website;
    }

    public void setCompany_website(String company_website) {
        this.company_website = company_website;
    }

    public String getCompany_logo() {
        return company_logo;
    }

    public void setCompany_logo(String company_logo) {
        this.company_logo = company_logo;
    }

    public String getCompany_address() {
        return company_address;
    }

    public void setCompany_address(String company_address) {
        this.company_address = company_address;
    }

    public String company_id;
    public String company_name;
    public String company_phone;
    public String company_email;
    public String company_website;
    public String company_logo;
    public String company_address;


    public String ibn_number;

    public String color;

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public String getIbn_number() {
        return ibn_number;
    }

    public void setIbn_number(String ibn_number) {
        this.ibn_number = ibn_number;
    }

    public String getPayment_bank_name() {
        return payment_bank_name;
    }

    public void setPayment_bank_name(String payment_bank_name) {
        this.payment_bank_name = payment_bank_name;
    }

    public String getPaypal_email() {
        return paypal_email;
    }

    public void setPaypal_email(String paypal_email) {
        this.paypal_email = paypal_email;
    }

    public String getPayment_swift_bic() {
        return payment_swift_bic;
    }

    public void setPayment_swift_bic(String payment_swift_bic) {
        this.payment_swift_bic = payment_swift_bic;
    }

    public String getCheque_payable_to() {
        return cheque_payable_to;
    }

    public void setCheque_payable_to(String cheque_payable_to) {
        this.cheque_payable_to = cheque_payable_to;
    }

    public String payment_bank_name;
    public String paypal_email;
    public String payment_swift_bic;
    public String cheque_payable_to;



    public String getCurrencyid() {
        return currencyid;
    }

    public void setCurrencyid(String currencyid) {
        this.currencyid = currencyid;
    }

    public String currencyid;

    public String getCompany_image_path() {
        return company_image_path;
    }

    public void setCompany_image_path(String company_image_path) {
        this.company_image_path = company_image_path;
    }

    public String company_image_path;



}
