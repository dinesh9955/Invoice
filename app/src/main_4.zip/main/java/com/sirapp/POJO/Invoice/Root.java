package com.sirapp.POJO.Invoice;

public class Root{
    public boolean status;
    public Data data;
    public String message;
}
